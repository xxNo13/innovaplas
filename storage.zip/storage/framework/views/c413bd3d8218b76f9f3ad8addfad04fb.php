<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('media/icon.png')); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('media/icon.png')); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <!-- Extra details for Live View on GitHub Pages -->
    
    <title>
        <?php echo e(config('app.name')); ?>

    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no'
        name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/2d643bcf3f.js" crossorigin="anonymous"></script>
    <!-- CSS Files -->
    <link href="<?php echo e(asset('plugins/bootstrap-5.3.3/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('paper/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('paper/css/paper-dashboard.css?v=2.0.0')); ?>" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="<?php echo e(asset('paper/demo/demo.css')); ?>" rel="stylesheet" />
    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body class="<?php echo e($class ?? ''); ?>">
    <div class="wrapper">

        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        <div class="main-panel">
            <!-- Header -->
            <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <div class="navbar-toggle">
                            <button type="button" class="navbar-toggler">
                                <span class="navbar-toggler-bar bar1"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </button>
                        </div>
                        <a class="navbar-brand" href="#pablo"><?php echo e(config('app.name')); ?></a>
                    </div>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation"
                        aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-end" id="navigation">
                        <ul class="navbar-nav">
                            <li class="nav-item btn-rotate dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <?php if(!empty(auth()->user()->unreadNotifications) && count(auth()->user()->unreadNotifications) > 0): ?>
                                        <span class="rounded-circle p-1 bg-success position-absolute start-50"></span>
                                    <?php endif; ?>
                                    <i class="nc-icon nc-bell-55"></i>
                                    <p>
                                        <span class="d-lg-none d-md-block"><?php echo e(__('Notifications')); ?></span>
                                    </p>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                    <?php if(!empty(auth()->user()->unreadNotifications) && count(auth()->user()->unreadNotifications) > 0): ?>
                                        <?php $__currentLoopData = auth()->user()->unreadNotifications->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a class="dropdown-item px-3" href="<?php echo e($notification->data['link'] ?? ''); ?>?read=<?php echo e($notification->id); ?>">
                                                <div>
                                                    <?php echo e($notification->data['message']); ?>

                                                </div>
                                                <small class="text-end d-block fst-italic" data-bs-toggle="tooltip"  title="<?php echo e($notification->created_at->format('d/m/Y h:i A')); ?>"><?php echo e($notification->created_at->diffForHumans()); ?></small>
                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <span class="dropdown-item px-3">
                                            <div>No Unread Notifications</div>
                                        </span>
                                    <?php endif; ?>
                                    <hr class="my-1">
                                    <a class="dropdown-item px-3" href="<?php echo e(route('notifications')); ?>">
                                        <div class="text-center">
                                            View all notifications
                                        </div>
                                    </a>
                                </div>
                            </li>
                            <li class="nav-item btn-rotate dropdown">
                                <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink2"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="nc-icon nc-settings-gear-65"></i>
                                    <p>
                                        <span class="d-lg-none d-md-block"><?php echo e(__('Account')); ?></span>
                                    </p>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink2">
                                    <form class="dropdown-item" action="<?php echo e(route('logout')); ?>" id="formLogOut" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                    <a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>"><?php echo e(__('My profile')); ?></a>
                                    <a class="dropdown-item" onclick="document.getElementById('formLogOut').submit();"><?php echo e(__('Log out')); ?></a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>            
            
            <?php echo $__env->yieldContent('content'); ?>

            <?php echo $__env->make('layouts.footer', ['containerCss' => 'container-fluid'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <!-- Customize Sidebar -->
        
    </div>

    <!--   Core JS Files   -->
    <script src="<?php echo e(asset('paper/js/core/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('paper')); ?>/js/core/popper.min.js"></script>
    <script src="<?php echo e(asset('plugins/bootstrap-5.3.3/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('paper/js/core/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('paper/js/plugins/perfect-scrollbar.jquery.min.js')); ?>"></script>
    <!-- Chart JS -->
    <script src="<?php echo e(asset('paper')); ?>/js/plugins/chartjs.min.js"></script>
    <!--  Notifications Plugin    -->
    <script src="<?php echo e(asset('paper/js/plugins/bootstrap-notify.js')); ?>"></script>
    <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="<?php echo e(asset('paper/js/paper-dashboard.js?v=2.0.0')); ?>" type="text/javascript"></script>
    <!-- Paper Dashboard DEMO methods, don't include it in your project! -->
    <script src="<?php echo e(asset('paper')); ?>/demo/demo.js"></script>
    
    <?php echo $__env->yieldPushContent('scripts'); ?>
    

    <script>
        $(document).ready(function () {
            $('body').on('input', 'input[type=number]', function () {
                if ($(this).attr('min')) {
                    if ($(this).val() < $(this).attr('min')) {
                        $(this).val($(this).attr('min'));
                    }
                }
            });
            
            $('body').on('click', '.btn-password', function () {
                var parent = $(this).closest('div');
                
                if ($(this).hasClass('fa-eye')) {
                    $(this).removeClass('fa-eye');
                    $(this).addClass('fa-eye-slash');
                    parent.find('input').attr('type', 'text');
                } else {
                    $(this).removeClass('fa-eye-slash');
                    $(this).addClass('fa-eye');
                    parent.find('input').attr('type', 'password');
                }
            });
        });
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\innovaplas\resources\views/layouts/backend.blade.php ENDPATH**/ ?>