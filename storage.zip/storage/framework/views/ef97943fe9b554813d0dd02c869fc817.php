<?php if(session('message')): ?>
    <div class="alert alert-success alert-dismissible mb-4" role="alert">
        <p class="mb-0"><?php echo app('translator')->get(session('message')); ?></p>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible mb-4" role="alert">
        <p class="mb-0"><?php echo app('translator')->get(session('error')); ?></p>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if($errors->has('message')): ?>
    <div class="alert alert-danger alert-dismissible mb-4" role="alert">
        <p class="mb-0"><?php echo app('translator')->get($errors->first('message')); ?></p>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if($errors->has('attempt')): ?>
    <div class="alert alert-danger alert-dismissible mb-4" role="alert">
        <p class="mb-0"><?php echo app('translator')->get($errors->first('attempt')); ?></p>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\innovaplas\resources\views/layouts/alert.blade.php ENDPATH**/ ?>